//
//  ViewController.swift
//  Actividad3
//
//  Created by Samantha Ramirez on 07/02/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
        @IBOutlet weak var sliderR: UISlider!
        @IBOutlet weak var sliderG: UISlider!
        @IBOutlet weak var sliderB: UISlider!
        @IBOutlet weak var sliderA: UISlider!
        @IBOutlet weak var labelR: UILabel!
        @IBOutlet weak var labelG: UILabel!
        @IBOutlet weak var labelB: UILabel!
        @IBOutlet weak var labelA: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Establece los sliders con el valor máximo
        sliderR.value = 1.0
        sliderG.value = 1.0
        sliderB.value = 1.0
        sliderA.value = 1.0
        
        //Actualizar las etiquetas con los valores iniciales
        updateLabels()
        
        //Actualiza el color del fondo de la imagen
        updateImageColor()
    }

    @IBAction func sliderChanged(_ sender: UISlider) {
            //Actualiza las etiquetas de los sliders
            updateLabels()
            
            //Actualiza el color del fondo de la imagen
            updateImageColor()
    }
    
    func updateLabels() {
        //Actualiza las etiquetas con los valores de los sliders
        labelR.text = "\(Int(sliderR.value * 255))"
        labelG.text = "\(Int(sliderG.value * 255))"
        labelB.text = "\(Int(sliderB.value * 255))"
        labelA.text = "\(sliderA.value)"
    }
    
    func updateImageColor() {
            //Obtiene los valores actuales de los sliders
            let redValue = CGFloat(sliderR.value)
            let greenValue = CGFloat(sliderG.value)
            let blueValue = CGFloat(sliderB.value)
            let alphaValue = CGFloat(sliderA.value)
            
            //Crea el nuevo color con los valores de los sliders RGB
            let newColor = UIColor(red: redValue, green: greenValue, blue: blueValue, alpha: alphaValue)
            
            //Asigna el nuevo color como fondo de la imagen
            imageView.backgroundColor = newColor

            //Cambiar la opacidad toda la imagen,
            //SI SOLO SE QUIERE CAMBIAR LA OPACIDAD DEL FONDO, BORRAR ESTA LINEA DE CODIGO (70)
            imageView.alpha = alphaValue
        }
}
